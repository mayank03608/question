from django.contrib import admin
from django.utils.html import format_html
from django.contrib import admin
from .models import JobApplication, JuniorAccountant, SeniorAccountant, It, BackOffice, Crm, Hrm

class JobApplicationAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'mobile_number', 'position_apply_for', 'application_date','score', 'view_report_link')
    search_fields = ('full_name', 'mobile_number')
    list_filter = ('position_apply_for',)
    readonly_fields = ('application_date','score') 

    def view_report_link(self, obj):
        # This method generates a link to view the report (result) of the job application
        return format_html('<a href="/user_result/{}/">View Report</a>', obj.id)
    view_report_link.short_description = 'View Report'
    
admin.site.register(JobApplication,JobApplicationAdmin)

class JuniorAccountantAdmin(admin.ModelAdmin):
    list_display = ['question', 'option_1', 'option_2', 'option_3', 'option_4', 'correct_option']  

    search_fields = ['question']  

admin.site.register(JuniorAccountant, JuniorAccountantAdmin)

class SeniorAccountantAdmin(admin.ModelAdmin):
    list_display = ['question', 'option_1', 'option_2', 'option_3', 'option_4', 'correct_option']  

    search_fields = ['question'] 

admin.site.register(SeniorAccountant, SeniorAccountantAdmin)

class ItAdmin(admin.ModelAdmin):
    list_display = ['question', 'option_1', 'option_2', 'option_3', 'option_4', 'correct_option']  

    search_fields = ['question'] 

admin.site.register(It, ItAdmin)

class BackOfficeAdmin(admin.ModelAdmin):
    list_display = ['question', 'option_1', 'option_2', 'option_3', 'option_4', 'correct_option']  

    search_fields = ['question'] 

admin.site.register(BackOffice, BackOfficeAdmin)

class CrmAdmin(admin.ModelAdmin):
    list_display = ['question', 'option_1', 'option_2', 'option_3', 'option_4', 'correct_option']  

    search_fields = ['question'] 

admin.site.register(Crm, CrmAdmin)

class HrmAdmin(admin.ModelAdmin):
    list_display = ['question', 'option_1', 'option_2', 'option_3', 'option_4', 'correct_option']  

    search_fields = ['question'] 

admin.site.register(Hrm, HrmAdmin)