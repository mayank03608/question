from django.db import models


class JobApplication(models.Model):
    POSITION_CHOICES = [
        ('junior_accountant', 'Junior Accountant'),
        ('senior_accountant', 'Senior Accountant'),
        ('it', 'IT'),
        ('back_office', 'Back Office'),
        ('hrm', 'HRM'),
        ('crm', 'CRM'),
    ]
    full_name = models.CharField(max_length=100)
    mobile_number = models.IntegerField(null=True)
    position_apply_for = models.CharField(max_length=50, choices=POSITION_CHOICES)
    application_date = models.DateTimeField(auto_now_add=True)
    score = models.FloatField(null=True, blank=True)  
    report = models.FileField(upload_to='reports/', null=True, blank=True)  



    
    def __str__(self):
        return f'{self.full_name} - {self.position_apply_for}'

class JuniorAccountant(models.Model):
    question = models.CharField(max_length=255)  # Question text
    option_1 = models.CharField(max_length=255)  # Option A
    option_2 = models.CharField(max_length=255)  # Option B
    option_3 = models.CharField(max_length=255)  # Option C
    option_4 = models.CharField(max_length=255)  
    correct_option = models.CharField(
        max_length=1, choices=[('1', 'Option 1'), ('2', 'Option 2'), ('3', 'Option 3'), ('4', 'Option 4')]
    )

    def __str__(self):
        return self.question

class SeniorAccountant(models.Model):
    question = models.CharField(max_length=255)  
    option_1 = models.CharField(max_length=255) 
    option_2 = models.CharField(max_length=255)  
    option_3 = models.CharField(max_length=255)  
    option_4 = models.CharField(max_length=255)  
    correct_option = models.CharField(
        max_length=1, choices=[('1', 'Option 1'), ('2', 'Option 2'), ('3', 'Option 3'), ('4', 'Option 4')]
    )

    def __str__(self):
        return self.question

class It(models.Model):
    question = models.CharField(max_length=255)  
    option_1 = models.CharField(max_length=255) 
    option_2 = models.CharField(max_length=255)  
    option_3 = models.CharField(max_length=255)  
    option_4 = models.CharField(max_length=255)  
    correct_option = models.CharField(
        max_length=1, choices=[('1', 'Option 1'), ('2', 'Option 2'), ('3', 'Option 3'), ('4', 'Option 4')]
    )

    def __str__(self):
        return self.question    
    
class BackOffice(models.Model):
    question = models.CharField(max_length=255)  
    option_1 = models.CharField(max_length=255) 
    option_2 = models.CharField(max_length=255)  
    option_3 = models.CharField(max_length=255)  
    option_4 = models.CharField(max_length=255)  
    correct_option = models.CharField(
        max_length=1, choices=[('1', 'Option 1'), ('2', 'Option 2'), ('3', 'Option 3'), ('4', 'Option 4')]
    )

    def __str__(self):
        return self.question   

class Crm(models.Model):
    question = models.CharField(max_length=255)  
    option_1 = models.CharField(max_length=255) 
    option_2 = models.CharField(max_length=255)  
    option_3 = models.CharField(max_length=255)  
    option_4 = models.CharField(max_length=255)  
    correct_option = models.CharField(
        max_length=1, choices=[('1', 'Option 1'), ('2', 'Option 2'), ('3', 'Option 3'), ('4', 'Option 4')]
    )

    def __str__(self):
        return self.question   

class Hrm(models.Model):
    question = models.CharField(max_length=255)  
    option_1 = models.CharField(max_length=255) 
    option_2 = models.CharField(max_length=255)  
    option_3 = models.CharField(max_length=255)  
    option_4 = models.CharField(max_length=255)  
    correct_option = models.CharField(
        max_length=1, choices=[('1', 'Option 1'), ('2', 'Option 2'), ('3', 'Option 3'), ('4', 'Option 4')]
    )

    def __str__(self):
        return self.question               
    
class Answer(models.Model):
    job_application = models.ForeignKey(JobApplication, on_delete=models.CASCADE)  # JobApplication से लिंक
    question = models.CharField(max_length=255)  # प्रश्न का टेक्स्ट
    user_answer = models.CharField(max_length=1)  # उपयोगकर्ता का उत्तर (1-4 के रूप में)

    def __str__(self):
        return f"Answer for {self.job_application.full_name} - {self.question}"    