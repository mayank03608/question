from django.shortcuts import render
from .forms import JobApplicationForm 
from .models import JobApplication
from django.shortcuts import render, redirect
from .forms import JobApplicationForm
from .models import JuniorAccountant,SeniorAccountant,It,Crm,BackOffice,Hrm

from .models import JobApplication

def job_application_form(request):
    if request.method == 'POST':
        full_name = request.POST['full_name']
        mobile_number = request.POST['mobile_number']
        position_apply_for = request.POST['position_apply_for']
        
        job_application = JobApplication(
            full_name=full_name,
            mobile_number=mobile_number,
            position_apply_for=position_apply_for
        )
        
     
        job_application.save()

    
        request.session['application_id'] = job_application.id

     
        request.session['completed'] = False    

        
        if position_apply_for == 'junior_accountant': 
            return redirect('junior_accountant')
        elif position_apply_for == 'senior_accountant':
            return redirect('senior_accountant')
        elif position_apply_for == 'it':
            return redirect('it')
        elif position_apply_for == 'back_office':
            return redirect('back_office')
        elif position_apply_for == 'hrm':
            return redirect('hrm')
        elif position_apply_for == 'crm':
            return redirect('crm')

    else:
        
        form = JobApplicationForm()

    
    return render(request, 'quiz/job_application_form.html', {'form': form})



def junior_accountant(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = JuniorAccountant.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        # Get existing answers from session or create a new list
        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        # Move to the next question
        request.session['question_index'] = question_index + 1

        # Track all question options for the current session
        questions_data = request.session.get('questions', [])
        questions_data.append({
            'question': current_question.question,
            'option_1': current_question.option_1,
            'option_2': current_question.option_2,
            'option_3': current_question.option_3,
            'option_4': current_question.option_4,
            'correct_option': current_question.correct_option
        })
        request.session['questions'] = questions_data

        return redirect('junior_accountant')

    return render(request, 'quiz/junior_accountant.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20  # Example time limit
    })


def result(request):
    if 'completed' not in request.session or not request.session['completed']:
        return redirect('junior_accountant')  

    # Get session data for answers and questions
    answers = request.session.get('answers', [])
    questions = request.session.get('questions', [])

    # Calculate correct and incorrect answers
    correct_count = sum(1 for ans in answers if ans['user_answer'] == ans['correct_answer'])
    total_questions = len(answers)  
    incorrect_count = total_questions - correct_count 

    # Calculate percentage
    percentage = (correct_count / total_questions) * 100 if total_questions > 0 else 0

    application_id = request.session.get('application_id')
    
    try:
        job_application = JobApplication.objects.get(id=application_id)
        job_application.score = percentage  # Update the score for the job application
        job_application.save()  
    except JobApplication.DoesNotExist:
        job_application = None  

    return render(request, 'quiz/result.html', {
        'correct_count': correct_count,       
        'incorrect_count': incorrect_count,  
        'percentage': percentage,             
        'total_questions': total_questions,   
        'job_application': job_application,
        'questions': questions,
        'answers': answers  # Send the answers data for result display
    })


def reset_quiz(request):
    request.session['completed'] = False
    request.session['question_index'] = 0
    request.session['answers'] = []
    return redirect('job_application_form')


def it(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = It.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('it')

    return render(request, 'quiz/it.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

def senior_accountant(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = SeniorAccountant.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('senior_accountant')

    return render(request, 'quiz/senior_accountant.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })


def hrm(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = Hrm.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('hrm')

    return render(request, 'quiz/hrm.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

def crm(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = Crm.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('crm')

    return render(request, 'quiz/crm.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

def back_office(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = BackOffice.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('back_office')

    return render(request, 'quiz/backoffice.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

